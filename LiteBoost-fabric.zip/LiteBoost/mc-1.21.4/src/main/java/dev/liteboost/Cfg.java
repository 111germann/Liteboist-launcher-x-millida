package dev.liteboost;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Настройки мода и профили оптимизации. Хранятся в config/liteboost.properties. */
public final class Cfg {
    public static boolean fps = true, mem = false, graph = true;
    public static int profile = 1; // 0 обычный, 1 лёгкий, 2 ультра-лёгкий
    public static final String[] NAMES = {"Обычный", "Лёгкий", "Ультра-лёгкий"};

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("liteboost.properties"); }

    public static void load() {
        Properties p = new Properties();
        try { p.load(Files.newInputStream(file())); } catch (IOException e) { return; }
        fps = Boolean.parseBoolean(p.getProperty("fps", "true"));
        mem = Boolean.parseBoolean(p.getProperty("mem", "false"));
        graph = Boolean.parseBoolean(p.getProperty("graph", "true"));
        try { profile = Math.max(0, Math.min(2, Integer.parseInt(p.getProperty("profile", "1")))); } catch (NumberFormatException ignored) {}
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("fps", String.valueOf(fps));
        p.setProperty("mem", String.valueOf(mem));
        p.setProperty("graph", String.valueOf(graph));
        p.setProperty("profile", String.valueOf(profile));
        try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "LiteBoost"); } catch (IOException ignored) {}
    }

    /** Применяет выбранный профиль к настройкам игры. */
    public static void apply(Options o) {
        switch (profile) {
            case 0 -> set(o, ParticleStatus.ALL, true, 2, 1.0, 12, 10);
            case 1 -> set(o, ParticleStatus.DECREASED, false, 1, 0.75, 8, 6);
            default -> set(o, ParticleStatus.MINIMAL, false, 0, 0.5, 6, 5);
        }
        o.save();
    }

    private static void set(Options o, ParticleStatus particles, boolean shadows, int blend, double entity, int render, int sim) {
        o.particles().set(particles);
        o.entityShadows().set(shadows);
        o.biomeBlendRadius().set(blend);
        o.entityDistanceScaling().set(entity);
        o.renderDistance().set(render);
        o.simulationDistance().set(sim);
    }
}
