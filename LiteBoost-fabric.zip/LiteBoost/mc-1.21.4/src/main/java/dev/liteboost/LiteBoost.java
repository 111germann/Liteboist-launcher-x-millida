package dev.liteboost;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class LiteBoost implements ClientModInitializer {
    public static KeyMapping MENU;

    @Override
    public void onInitializeClient() {
        Cfg.load();
        MENU = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.liteboost.menu", InputConstants.Type.KEYSYM, InputConstants.KEY_RSHIFT, "key.categories.liteboost"));
        HudRenderCallback.EVENT.register((g, dt) -> Hud.render(g));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (MENU.consumeClick()) mc.setScreen(new MenuScreen(null));
        });
        // При самом первом запуске сразу применяем профиль «Лёгкий».
        ClientLifecycleEvents.CLIENT_STARTED.register(mc -> {
            Path flag = FabricLoader.getInstance().getConfigDir().resolve("liteboost.applied");
            if (Files.exists(flag)) return;
            Cfg.apply(mc.options); Cfg.save();
            try { Files.createFile(flag); } catch (IOException ignored) {}
        });
    }
}
