package dev.liteboost;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Экран FPS: счётчик, ОЗУ и график времени кадра. */
public final class Hud {
    private static long lastFrame = System.nanoTime(), lastSec = lastFrame;
    private static int frames = 0, fps = 0, idx = 0;
    private static final float[] FT = new float[60];

    private static int col(float ms) { return ms <= 17.5f ? 0xFF4ADE80 : ms <= 34f ? 0xFFFACC15 : 0xFFF87171; }
    private static void t(GuiGraphicsExtractor g, Minecraft mc, String s, int x, int y, int c) { g.text(mc.font, s, x, y, c, true); }

    public static void render(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        long now = System.nanoTime();
        FT[idx] = (now - lastFrame) / 1_000_000f; idx = (idx + 1) % 60; lastFrame = now; frames++;
        if (now - lastSec >= 1_000_000_000L) { fps = frames; frames = 0; lastSec = now; }

        int lines = (Cfg.fps ? 1 : 0) + (Cfg.mem ? 1 : 0);
        if (lines == 0 && !Cfg.graph) return;
        int x = 8, y = 8, w = 128, h = 4 + lines * 11 + (Cfg.graph ? 30 : 0);
        int ac = col(1000f / Math.max(1, fps));
        g.fill(x - 4, y - 4, x + w, y + h, 0xA0101624);
        g.fill(x - 4, y - 4, x - 2, y + h, ac);
        int ty = y;
        if (Cfg.fps) { t(g, mc, "FPS " + fps, x, ty, ac); ty += 11; }
        if (Cfg.mem) {
            Runtime r = Runtime.getRuntime();
            t(g, mc, "ОЗУ " + ((r.totalMemory() - r.freeMemory()) >> 20) + "/" + (r.maxMemory() >> 20) + " МБ", x, ty, 0xFFE5E7EB);
            ty += 11;
        }
        if (Cfg.graph) {
            int gy = ty + 2;
            g.fill(x, gy + 24, x + 120, gy + 25, 0x60FFFFFF);
            for (int i = 0; i < 60; i++) {
                float v = FT[(idx + i) % 60];
                int hh = Math.min(24, Math.round(v * 0.75f));
                g.fill(x + i * 2, gy + 24 - hh, x + i * 2 + 1, gy + 24, col(v));
            }
        }
    }
}
