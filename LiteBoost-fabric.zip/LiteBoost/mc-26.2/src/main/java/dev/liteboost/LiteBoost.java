package dev.liteboost;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class LiteBoost implements ClientModInitializer {
    public static KeyMapping MENU;

    @Override
    public void onInitializeClient() {
        Cfg.load();
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("liteboost", "main"));
        MENU = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.liteboost.menu", InputConstants.Type.KEYSYM, InputConstants.KEY_RSHIFT, cat));
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("liteboost", "hud"), (g, dt) -> Hud.render(g));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (MENU.consumeClick()) mc.setScreenAndShow(new MenuScreen(null));
        });
        // При самом первом запуске сразу применяем профиль «Лёгкий».
        ClientLifecycleEvents.CLIENT_STARTED.register(mc -> {
            Path flag = FabricLoader.getInstance().getConfigDir().resolve("liteboost.applied");
            if (Files.exists(flag)) return;
            Cfg.apply(mc.options); Cfg.save();
            try { Files.createFile(flag); } catch (IOException ignored) {}
        });
    }
}
