package dev.liteboost;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Меню настроек LiteBoost (открывается клавишей Right Shift). */
public class MenuScreen extends Screen {
    private final Screen parent;

    public MenuScreen(Screen parent) { super(Component.literal("LiteBoost")); this.parent = parent; }

    private static Component prof() { return Component.literal("Профиль: " + Cfg.NAMES[Cfg.profile]); }
    private static Component tog(String n, boolean v) { return Component.literal(n + ": " + (v ? "вкл" : "выкл")); }

    @Override
    protected void init() {
        int cx = this.width / 2, y = this.height / 2 - 50, w = 200, x = cx - w / 2;
        addRenderableWidget(Button.builder(prof(), b -> {
            Cfg.profile = (Cfg.profile + 1) % 3;
            Cfg.apply(this.minecraft.options); Cfg.save(); b.setMessage(prof());
        }).bounds(x, y, w, 20).build());
        addRenderableWidget(Button.builder(tog("Счётчик FPS", Cfg.fps), b -> {
            Cfg.fps = !Cfg.fps; Cfg.save(); b.setMessage(tog("Счётчик FPS", Cfg.fps));
        }).bounds(x, y + 26, w, 20).build());
        addRenderableWidget(Button.builder(tog("Память (ОЗУ)", Cfg.mem), b -> {
            Cfg.mem = !Cfg.mem; Cfg.save(); b.setMessage(tog("Память (ОЗУ)", Cfg.mem));
        }).bounds(x, y + 52, w, 20).build());
        addRenderableWidget(Button.builder(tog("График кадров", Cfg.graph), b -> {
            Cfg.graph = !Cfg.graph; Cfg.save(); b.setMessage(tog("График кадров", Cfg.graph));
        }).bounds(x, y + 78, w, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose()).bounds(x, y + 108, w, 20).build());
    }

    @Override
    public void onClose() { this.minecraft.setScreenAndShow(this.parent); }

    private void center(GuiGraphicsExtractor g, String s, int cx, int y, int c) { g.text(this.font, s, cx - this.font.width(s) / 2, y, c, true); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float d) {
        super.extractRenderState(g, mx, my, d);
        int cx = this.width / 2, top = this.height / 2 - 82, bot = this.height / 2 + 86, l = cx - 112, r = cx + 112;
        int c = 0xFF22C55E;
        g.fill(l, top, r, top + 2, c); g.fill(l, bot, r, bot + 2, c);
        g.fill(l, top, l + 2, bot + 2, c); g.fill(r - 2, top, r, bot + 2, c);
        center(g, "LiteBoost", cx, top + 8, c);
        center(g, "Оптимизация графики", cx, top + 20, 0xFF9CA3AF);
        center(g, "Профиль меняет частицы, тени, дальность", cx, bot + 8, 0xFF9CA3AF);
    }
}
